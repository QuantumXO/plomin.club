<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']        	= 'Opencart';

// Text
$_['text_order']          	= 'Замовлення';
$_['text_processing_status']    = 'В процесі';
$_['text_complete_status']      = 'Завершено';
$_['text_customer']          	= 'Покупці';
$_['text_online']          	= 'Онлайн';
$_['text_approval']          	= 'В очікуванні';
$_['text_product']          	= 'Товари';
$_['text_stock']          	= 'Нема у наявності';
$_['text_review']          	= 'Відгуки';
$_['text_return']          	= 'Повернення';
$_['text_affiliate']          	= 'Партнерська програма';
$_['text_store']          	= 'Магазини';
$_['text_front']          	= 'Магазин';
$_['text_help']          	= 'Допомога';
$_['text_homepage']          	= 'Головна';
$_['text_support']          	= 'Форум техпідтримки';
$_['text_documentation']        = 'Документація';
$_['text_logout']          	= 'Вихід';
//NewStore
$_['title_callback']            = 'Зворотній дзвінок';
//Oppro
//OpPro
$_['text_search_options']  		  = 'Опції пошуку';
$_['text_new']  		   		  = 'Добавити';
$_['text_new_category']    		  = 'Категорію';
$_['text_new_customer']    		  = 'Користувача';
$_['text_new_download']           = 'Завантаження';
$_['text_new_manufacturer']		  = 'Виробника';
$_['text_new_product']     		  = 'Товар';
$_['button_clearallcache']        = 'Видалити весь кеш';
$_['button_clearcache']           = 'Видалити кеш зображеннь';
$_['button_clearsystemcache']     = 'Видалити системний кеш';