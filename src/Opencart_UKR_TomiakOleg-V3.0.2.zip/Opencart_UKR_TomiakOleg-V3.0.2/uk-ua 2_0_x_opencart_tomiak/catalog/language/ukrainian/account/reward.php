<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Heading 
$_['heading_title']      = 'Бонусні бали';

// Column
$_['column_date_added']  = 'Дата нарахування';
$_['column_description'] = 'Нараховано за:';
$_['column_points']      = 'Всього балів';

// Text
$_['text_account']       = 'Особистий Кабінет';
$_['text_reward']        = 'Бонусні бали';
$_['text_total']         = 'Накопичено Бонусних балів:';
$_['text_empty']         = 'У Вас немає Бонусних балів!';