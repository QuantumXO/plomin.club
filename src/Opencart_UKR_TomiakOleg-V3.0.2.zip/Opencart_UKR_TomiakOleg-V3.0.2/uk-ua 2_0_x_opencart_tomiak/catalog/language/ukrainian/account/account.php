<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Heading 
$_['heading_title']      = 'Особистий кабінет';

// Text
$_['text_account']       = 'Особистий кабінет';
$_['text_my_account']    = 'Мій обліковий запис';
$_['text_my_orders']     = 'Мої замовлення';
$_['text_my_newsletter'] = 'Підписка';
$_['text_edit']          = 'Основні дані';
$_['text_password']      = 'Змінити свій пароль';
$_['text_address']       = 'Змінити мої адреси';
$_['text_wishlist']      = 'Змінити закладки';
$_['text_order']         = 'Історія замовлень';
$_['text_download']      = 'Файли для скачування';
$_['text_reward']        = 'Бонусні бали';
$_['text_return']        = 'Заявки на повернення';
$_['text_transaction']   = 'Історія платежів';
$_['text_newsletter']    = 'Редагувати підписку';
$_['text_recurring']     = 'Регулярні платежі';
$_['text_transactions']  = 'Перекази';