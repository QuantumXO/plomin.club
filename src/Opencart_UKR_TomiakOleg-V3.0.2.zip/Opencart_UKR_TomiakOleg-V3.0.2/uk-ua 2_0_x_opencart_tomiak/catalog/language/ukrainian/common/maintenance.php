<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title']    = 'Режим обслуговування';

// Text
$_['text_maintenance'] = 'Режим обслуговування';
$_['text_message']     = '<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><h1 style="text-align:center;">В даний час магазин закритий на технічне обслуговування. <br/> Будь ласка, зайдіть трохи пізніше!</h1><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>';