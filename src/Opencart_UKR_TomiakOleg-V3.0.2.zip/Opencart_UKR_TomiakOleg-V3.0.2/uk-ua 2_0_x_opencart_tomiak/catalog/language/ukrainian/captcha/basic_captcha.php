<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Введіть код, який бачите нижче';

// Error
$_['error_captcha'] = 'Код введено з помилкою!';
