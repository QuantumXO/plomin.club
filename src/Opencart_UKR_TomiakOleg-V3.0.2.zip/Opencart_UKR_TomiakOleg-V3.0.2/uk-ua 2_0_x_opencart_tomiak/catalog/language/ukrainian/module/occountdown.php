<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
$_['heading_title']     = 'До закінчення акції залишилось';

//Text
$_['text_reviews']      = '%s reviews';
$_['text_years']        = "Рік";
$_['text_months']       = "Місяці";
$_['text_weeks']        = "Тижні";
$_['text_days']         = "Дні";
$_['text_hours']        = "Годин";
$_['text_minutes']      = "Хвилин";
$_['text_seconds']      = "Секунд";
$_['text_sale']      = 'Акція';
$_['text_new']      = 'Новинка';
$_['text_empty']    = 'Наразі всі Акції закінчились';
?>
