<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
$_['text_foto'] = 'Зображення';
$_['text_name'] = 'Назва';
$_['text_manufacturer'] = 'Бренд';
$_['text_quantity'] = 'Кількість';
$_['text_price'] = 'Вартість';
$_['text_total'] = 'Сума: ';
$_['text_empty'] = 'В вашій корзині немає товарів!';
$_['text_in_stock'] = 'На нашому складі';
$_['text_left'] = 'залишилось';
$_['text_left1'] = 'залишилось';
$_['text_just'] = 'всього';
$_['text_pcs'] = 'шт.';
?>