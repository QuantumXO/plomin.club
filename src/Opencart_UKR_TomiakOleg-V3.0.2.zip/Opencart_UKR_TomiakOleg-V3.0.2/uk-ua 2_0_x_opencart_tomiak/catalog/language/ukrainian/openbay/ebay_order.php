<?php
// Text
$_['text_total_shipping']		= 'Доставка';
$_['text_total_discount']		= 'Знижка';
$_['text_total_tax']			= 'Податок';
$_['text_total_sub']			= 'Сума';
$_['text_total']				= 'Всього';
$_['text_smp_id']				= 'Selling Manager sale ID: ';
$_['text_buyer']				= 'Buyer username: ';