<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
$_['text_klarna_fee'] = 'Klarna Fee';