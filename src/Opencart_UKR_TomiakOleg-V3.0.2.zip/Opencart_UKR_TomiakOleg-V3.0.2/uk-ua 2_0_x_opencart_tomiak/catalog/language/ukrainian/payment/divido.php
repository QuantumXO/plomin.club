<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart

$_['text_checkout_title']      = 'Оплата в розстрочку';
$_['text_choose_plan']         = 'Виберіть Ваш план';
$_['text_choose_deposit']      = 'Виберіть Ваш депозит';
$_['text_monthly_payments']    = 'Місячний платіж';
$_['text_months']              = 'місяців';
$_['text_term']                = 'термін';
$_['text_deposit']             = 'Депозит';
$_['text_credit_amount']       = 'Вартість кредиту';
$_['text_amount_payable']      = 'Разом до оплати';
$_['text_total_interest']      = 'разом відсотки APR';
$_['text_monthly_installment'] = 'Місячний платіж';
$_['text_redirection']         = 'Ви будете перенаправлені на Divido для завершення фінансової операції після завершення замовлення';
$_['divido_checkout']          = 'Підтвердити і перейти на Divido';
$_['deposit_to_low']           = 'Найнищий депозит';
$_['credit_amount_to_low']     = 'Найнища сума кредита';
$_['no_country']               = 'Ваша країна не підтримується для даного методу';
