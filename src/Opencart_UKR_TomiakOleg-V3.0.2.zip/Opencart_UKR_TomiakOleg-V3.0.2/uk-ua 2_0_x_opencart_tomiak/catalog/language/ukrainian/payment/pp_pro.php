<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_title']			= 'Кредитна / Розрахункова картка (обробка надійно PayPal)';
$_['text_wait']				= 'Будь ласка, зачекайте!';
$_['text_credit_card']			= 'Дані кредитної картки';
$_['text_loading']			= 'Йде завантаження';

// Entry
$_['entry_cc_type']			= 'Тип картки';
$_['entry_cc_number']			= 'Номер картки';
$_['entry_cc_start_date']		= 'Картка діє з';
$_['entry_cc_expire_date']		= 'Термін дії картки';
$_['entry_cc_cvv2']			= 'Код безпеки картки (CVV2)';
$_['entry_cc_issue']			= 'Номер картки';

// Help
$_['help_start_date']			= '(якщо є)';
$_['help_issue']			= '(тільки для карток Maestro і Solo)';