<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart

// Heading
$_['heading_title']			= 'Будь ласка виберіть Ваш платіжний план';

// Text
$_['text_title']			= 'PUT IT ON LAY-BUY від PayPal';
$_['text_plan_preview']		= 'Попередній План';
$_['text_payment']			= 'Оплата';
$_['text_due_date']			= 'Дата';
$_['text_amount']			= 'Сума';
$_['text_downpayment']		= 'Аванс';
$_['text_today']			= 'Сьогодні';
$_['text_delivery_msg']		= 'Ваші товари/послуги будуть доставлені як тільки буде отриманий Ваш останній платіж';
$_['text_fee_msg']			= ' 0.9% адміністративна оплата Lay-Buys.com.';
$_['text_month']			= 'Місяць';
$_['text_months']			= 'Місяців';
$_['text_status_1']			= 'Виставлено';
$_['text_status_5']			= 'Успішно';
$_['text_status_7']			= 'Відмінено';
$_['text_status_50']		= 'Переглянути запит';
$_['text_status_51']		= 'Перевізовано';
$_['text_comment']			= 'Оновлено на Lay-Buy';

// Entry
$_['entry_initial']			= 'Ініційований платіж';
$_['entry_months']			= 'Місяців';

// Button
$_['button_confirm']		= 'Підтвердити замовлення';