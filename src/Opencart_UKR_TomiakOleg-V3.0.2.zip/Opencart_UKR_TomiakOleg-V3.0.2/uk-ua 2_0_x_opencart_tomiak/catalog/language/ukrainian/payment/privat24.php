<?php
// Text
$_['text_title'] = 'Приват24';
?>