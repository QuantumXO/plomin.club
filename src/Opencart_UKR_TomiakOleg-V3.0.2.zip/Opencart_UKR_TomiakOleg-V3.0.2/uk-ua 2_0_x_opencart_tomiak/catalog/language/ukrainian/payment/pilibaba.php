<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_title']        = 'Pilibaba (Китай)';
$_['text_redirecting']  = 'Перенаправлення...';