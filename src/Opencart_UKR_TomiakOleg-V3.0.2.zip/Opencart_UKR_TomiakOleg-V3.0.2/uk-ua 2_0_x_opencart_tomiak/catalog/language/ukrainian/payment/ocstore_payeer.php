<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
/**
 * Support:
 * https://opencartforum.com/user/3463-shoputils/
 * http://opencart.shoputils.ru/?route=information/contact
 * 
*/

// Text
$_['text_order_description']      = 'Оплата замовлення №%d, на суму: %s (%s)';

$_['text_comment']                = 'Payeer: %s. Сума: %s. Номер транзакції: %s';
$_['text_description']            = 'Можливі методи оплати: <br/><img src="%scatalog/view/theme/default/image/ocstore_payeer.jpg" title="Методи оплати" alt="Методи оплати"/>';
$_['text_payeer_onpay']           = 'Будь ласка, оплатіть покупку за наступним посиланням: %s';

$_['text_error_post']             = 'Відповідь від шлюзу не типу POST';
$_['text_error_m_sign']           = 'Некоректний підпис повідомлення від платіжного шлюзу';
$_['text_error_order_not_found']  = 'Замовлення №%s не знайдене';
$_['error_fail_checkout_extension'] = 'Даний модуль оформлення замовлення не підтримується платіжним модулем!';
?>