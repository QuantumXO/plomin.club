<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart

// Text
$_['text_title']       = 'Наші способи доставки';
$_['text_description'] = 'Наші способи доставки';
?>