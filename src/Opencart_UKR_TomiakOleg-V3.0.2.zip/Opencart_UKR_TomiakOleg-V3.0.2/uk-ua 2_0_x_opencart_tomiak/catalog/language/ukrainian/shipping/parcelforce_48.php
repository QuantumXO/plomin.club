<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Вага:';
$_['text_insurance']   = 'Страхувати на суму:';
$_['text_time']        = 'Приблизний час: протягом 48 годин';