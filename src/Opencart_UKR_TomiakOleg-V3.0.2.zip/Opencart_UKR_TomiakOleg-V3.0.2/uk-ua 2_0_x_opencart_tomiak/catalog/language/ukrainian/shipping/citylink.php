<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_title']  = 'Citylink';
$_['text_weight'] = 'Вага:';