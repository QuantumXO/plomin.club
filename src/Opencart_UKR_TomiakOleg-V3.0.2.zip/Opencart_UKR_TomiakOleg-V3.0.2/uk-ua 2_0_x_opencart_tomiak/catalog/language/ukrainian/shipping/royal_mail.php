<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_title']                        = 'Royal Mail';
$_['text_weight']                       = 'Вага:';
$_['text_insurance']                    = 'Страхувати на суму:';
$_['text_special_delivery']             = 'Special Delivery Next Day';
$_['text_1st_class_signed']             = 'First Class Signed Post';
$_['text_2nd_class_signed']             = 'Second Class Signed Post';
$_['text_1st_class_standard']           = 'Стандартна пошта першого класу';
$_['text_2nd_class_standard']           = 'Стандартна пошта другого класу';
$_['text_international_standard']       = 'International Standard';
$_['text_international_tracked_signed'] = 'International Tracked & Signed';
$_['text_international_tracked']        = 'International Tracked';
$_['text_international_signed']         = 'Міжнародна з підписом';
$_['text_international_economy']        = 'International Economy';
