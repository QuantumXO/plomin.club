<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_title']       = 'PiliExpress доставка';
$_['text_description'] = 'PiliExpress Піліекспрес(Китай), тільки для Pilibaba)';