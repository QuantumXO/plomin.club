<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_title']  = 'United States Postal Service';
$_['text_weight'] = 'Вага:';
$_['text_eta']    = 'Приблизний час:';