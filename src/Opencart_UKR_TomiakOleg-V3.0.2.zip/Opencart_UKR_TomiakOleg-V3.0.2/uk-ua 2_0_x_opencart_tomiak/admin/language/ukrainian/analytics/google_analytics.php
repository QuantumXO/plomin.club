<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
$_['heading_title']    = 'Google аналітика';

// Text
$_['text_analytics']   = 'Статистика';
$_['text_success']     = 'Налаштування модуля Google Analytics успішно оновлені';
$_['text_edit']        = 'Редагування Google Analytics';
$_['text_signup']      = 'Авторизуйтесь на сайті <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a>, створіть " Новий Ресурс" і скопіюйте " Код відстеження " в полі нижче:';

// Entry
$_['entry_code']       = 'Код відстеження';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Увага! У васт немає дозволів для редагування Google Analytics!';
$_['error_code']       = 'Код відстеження!';
