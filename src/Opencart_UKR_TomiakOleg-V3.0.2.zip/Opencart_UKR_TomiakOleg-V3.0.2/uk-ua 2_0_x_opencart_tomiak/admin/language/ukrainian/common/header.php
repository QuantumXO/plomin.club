<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']        	= 'Opencart';

// Text
$_['text_order']          	= 'Замовлення';
$_['text_processing_status']    = 'В процесі';
$_['text_complete_status']      = 'Завершено';
$_['text_customer']          	= 'Покупці';
$_['text_online']          	= 'Онлайн';
$_['text_approval']          	= 'В очікуванні';
$_['text_product']          	= 'Товари';
$_['text_stock']          	= 'Немає в наявності';
$_['text_review']          	= 'Відгуки';
$_['text_return']          	= 'Повернення';
$_['text_affiliate']          	= 'Партнерська програма';
$_['text_store']          	= 'Магазини';
$_['text_front']          	= 'Магазин';
$_['text_help']          	= 'Допомога';
$_['text_homepage']          	= 'Головна';
$_['text_support']          	= 'Форум техпідтримки';
$_['text_documentation']        = 'Документація';
$_['text_logout']          	= 'Вихід';
$_['title_callback']            = 'Зворотній дзвінок';