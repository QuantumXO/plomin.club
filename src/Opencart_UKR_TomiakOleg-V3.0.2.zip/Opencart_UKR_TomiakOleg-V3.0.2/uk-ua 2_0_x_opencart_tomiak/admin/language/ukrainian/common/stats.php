<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
$_['text_complete_status']       = 'Виконаних замовлень';
$_['text_processing_status']     = 'Замовлень в обробці';
$_['text_other_status']          = 'Інші статуси';