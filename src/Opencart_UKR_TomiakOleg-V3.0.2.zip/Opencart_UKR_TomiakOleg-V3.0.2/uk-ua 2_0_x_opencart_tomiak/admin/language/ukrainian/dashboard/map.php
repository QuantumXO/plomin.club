<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] = 'Продажі за країнами';

$_['text_order']    = 'Замовлення';
$_['text_sale']     = 'Продажі';