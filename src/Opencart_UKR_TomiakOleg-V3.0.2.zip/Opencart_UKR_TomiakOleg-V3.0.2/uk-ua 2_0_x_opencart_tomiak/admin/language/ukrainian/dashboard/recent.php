<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']    	= 'Останні замовлення';

// Column
$_['column_order_id']   = 'Замовлення №';
$_['column_customer']   = 'Покупець';
$_['column_status']     = 'Статус';
$_['column_total']      = 'На суму';
$_['column_date_added'] = 'Дата замовлення';
$_['column_action']     = 'Дія';
