<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] 	= 'Усього покупців';

// Text
$_['text_view'] 	= 'Детальніше...';