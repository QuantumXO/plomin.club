<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title']           = 'Видалити кеш';

// Button
$_['button_image']            = 'Картинка';
$_['button_system']           = 'Система';

// Text
$_['text_cache']              = '';
$_['text_delete']             = 'Очистити кеш ';
$_['text_buttons_help']       = 'Файди папки будуть видалені ';
$_['text_system']             = 'Видалити кеш ';
$_['text_description']        = 'Інструмент видалення картинок кешу (image/cache/) and system (system/storage/cache/)';
$_['text_octeam_toolset']     = 'OC Team Інструменти';

// Error
$_['error_permission']        = 'У Вас немає дозволів для видалення файлів кешу!';
$_['error_not_found']         = 'Не знайдено папку з файлами кешу';
?>