<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] 	= 'Звіт по Бонусних балам покупця';

// Text
$_['text_list'] 	= 'Перелік покупців по Бонусним балам';

// Column
$_['column_customer'] = 'Покупець';
$_['column_email'] 	= 'E-Mail';
$_['column_customer_group'] = 'Група покупця';
$_['column_status'] 	= 'Статус';
$_['column_points'] 	= 'Бонусні бали';
$_['column_orders'] 	= 'Кількість замовлень';
$_['column_total'] 	= 'Разом';
$_['column_action'] 	= 'Дія';

// Entry
$_['entry_date_start'] = 'Дата початку:';
$_['entry_date_end'] 	= 'Дата закінчення:';