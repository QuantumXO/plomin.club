<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] 	= 'Звіт про Онлайн користувачах';
// Jtext
$_['text_list'] 	= 'Перелік Онлайн покупців';
$_['text_guest'] 	= 'Гість';
// Column
$_['column_ip'] 	= 'IP';
$_['column_customer'] 	= 'Покупець';
$_['column_url'] 	= 'Остання відвідана сторінка';
$_['column_referer'] 	= 'Звідки прийшов';
$_['column_date_added'] = 'Останній клік';
$_['column_action'] 	= 'Дія';
// Entry
$_['entry_ip'] 		= 'IP адреса:';
$_['entry_customer'] 	= 'Покупець:';