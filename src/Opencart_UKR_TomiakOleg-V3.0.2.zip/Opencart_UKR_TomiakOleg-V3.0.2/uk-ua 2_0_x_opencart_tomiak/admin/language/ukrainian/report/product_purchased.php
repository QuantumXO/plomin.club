<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title']     = 'Звіт з Продажу';

// Text
$_['text_list']         = 'Перелік Проданих товарів';
$_['text_all_status']   = 'Усі статуси';

// Column
$_['column_date_start'] = 'Дата початку';
$_['column_date_end']   = 'Дата закінчення';
$_['column_name']       = 'Найменування товарів';
$_['column_model']      = 'Модель';
$_['column_quantity']   = 'Кільість';
$_['column_total']      = 'Всього';

// Entry
$_['entry_date_start']  = 'Дата почтаку:';
$_['entry_date_end']    = 'Дата закінчення:';
$_['entry_status']      = 'Статуси заказів:';