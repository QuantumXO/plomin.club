<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title']           = 'OC Team додаток';

// Text
$_['text_install']            = 'Встановити';
$_['text_uninstall']          = 'Деінсталювати';
$_['text_open']               = 'Відкрити';

// Column
$_['column_name']             = 'Назва додатку';
$_['column_description']      = 'Опис';
$_['column_action']           = 'Дія';

// Error
$_['error_permission']        = 'Увага! У Вас немає прав для редагування додатку!';
?>