<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] 	= 'Доставка з оплатою за одиницю';
// Jtext
$_['text_shipping'] 	= 'Доставка';
$_['text_success'] 	= 'Налаштування модуля успішно оновлені!';
$_['text_edit'] 	= 'Редагування модуля';
// Entry
$_['entry_cost'] 	= 'Вартість:';
$_['entry_tax_class'] 	= 'Клас податку:';
$_['entry_geo_zone'] 	= 'Географічна зона:';
$_['entry_status'] 	= 'Статус:';
$_['entry_sort_order'] 	= 'Порядок сортування:';
// Error
$_['error_permission'] 	= 'У Вас немає прав для управління цим модулем!';