<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] = 'Авторизація через Amazon';

//Text
$_['text_module'] = 'Модулі';
$_['text_success'] = 'Успішно: Ви модифікували модуль Login with Amazon!';
$_['text_content_top'] = 'Контент-тп';
$_['text_content_bottom'] = 'Контент-фон';
$_['text_column_left'] = 'ліва колонка';
$_['text_column_right'] = 'права колонка';
$_['text_lwa_button'] = 'Login with Amazon';
$_['text_login_button'] = 'Login';
$_['text_a_button'] = 'A';
$_['text_gold_button'] = 'Gold';
$_['text_darkgray_button'] = 'Dark Gray';
$_['text_lightgray_button'] = 'Light Gray';
$_['text_small_button'] = 'Small';
$_['text_medium_button'] = 'Medium';
$_['text_large_button'] = 'Large';
$_['text_x_large_button'] = 'X-Large';

//Entry
$_['entry_button_type'] = 'Кнопка тип';
$_['entry_button_colour'] = 'Кнопка колір';
$_['entry_button_size'] = 'Кнопка розмір';
$_['entry_layout'] = 'Розкладка';
$_['entry_position'] = 'Позиція';
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Сортування';

//Error
$_['error_permission'] = 'Увага! У Вас немає дозволів на редагування модуля Login with Amazon!';