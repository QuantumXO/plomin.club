<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']    = 'Оформлення замовлення через PayPal Express';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified PayPal Express Checkout Button module!';
$_['text_edit']        = 'Редагування модуля';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Попередження: Ви не маєте права модіфікувати модуль PayPal Express Checkout Button!';