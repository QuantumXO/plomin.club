<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']    = 'Lay-Buy Layout модуль';

// Text
$_['text_extension']   = 'Розширення/модуль';
$_['text_success']     = 'Успішно: Ви модифікували модуль Lay-Buy Layout!';
$_['text_edit']        = 'Редагувати модуль Lay-Buy Layout';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Увага: у Вас немає дозволів для редагування модуля Lay-Buy Layout!';