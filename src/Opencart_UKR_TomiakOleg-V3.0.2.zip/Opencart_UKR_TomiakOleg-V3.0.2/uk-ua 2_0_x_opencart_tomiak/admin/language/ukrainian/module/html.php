<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']     = 'HTML Вміст';

// Text
$_['text_module']       = 'Модулі';
$_['text_success']      = 'Модуль успішно встановлено!';
$_['text_edit']         = 'Редагування модуля';

// Entry
$_['entry_name']        = 'Назва';
$_['entry_title']       = 'Заголовок';
$_['entry_description'] = 'Опис';
$_['entry_status']      = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає прав для управління цим модулем!';
$_['error_name']        = 'Назва модуля має бути від 3 до 64 символів!';