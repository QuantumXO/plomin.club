<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']	   = 'Divido Product Page Calculator модуль';

// Text
$_['text_extension']   = 'Розширення';
$_['text_success']	   = 'Успішно: Ви модифікували модуль Divido Product Page Calculator!';
$_['text_edit']		   = 'Редагувати Divido Product Page Calculator';

// Entry
$_['entry_status']	   = 'Статус';

// Error
$_['error_permission'] = 'Увага! У Вас немає дозволів на редагування модуля Divido Product Page Calculator!';
