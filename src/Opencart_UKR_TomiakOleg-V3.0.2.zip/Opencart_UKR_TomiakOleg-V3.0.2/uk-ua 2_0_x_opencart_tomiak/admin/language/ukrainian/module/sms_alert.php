<?php
// Heading
$_['heading_title']    = 'Сповіщення по SMS &copy; <a href="http://opencart-russia.ru/">opencart-russia.ru</a>';
$_['heading_title1']    = 'Сповіщення по SMS &copy;  opencart-russia.ru';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Налаштування успешно змінені!';
$_['text_edit']        = 'Налаштування модуля';

// Entry
$_['entry_sms_alert_tel']       = 'Номер телефона для сповіщення про заказ';
$_['entry_sms_alert_id']       = 'Ваш API_ID';
$_['entry_processing_status']       = 'Статуси замовлення для сповіщення';


$_['entry_status']     = 'Статус';

// Help
$_['entry_sms_alert_help']       = '
	<h2>Инструкция по настройке:</h2><br>
	1. Перейдіть на <a href="http://opencartrussia.sms.ru/?panel=register" target="_blank"><strong>сайт SMS сервісу</strong></a> і зареєструйтесь.<br><br>
	2. В особистому кабінеті подивіться <a href="http://opencartrussia.sms.ru/?panel=settings&subpanel=api"><strong>API_ID</strong></a> і повертайтесь до налаштуваннь.<br><br>
	3. Заповніть поля, переключіть Статус на <strong>Включено</strong> і збережіть налаштування.
';
			
// Error
$_['error_permission'] 		= 'У Вас немає прав для управління даним модулем!';
$_['error_sms_alert_tel']       = 'Необхідний телефон для сповіщення';
$_['error_sms_alert_id']       = 'Необхідний ваш API_ID з особистого кабінету';
$_['error_sms_alert_processing_status']       = 'Необхідно вибрати статус замовлення для сповіщення';





