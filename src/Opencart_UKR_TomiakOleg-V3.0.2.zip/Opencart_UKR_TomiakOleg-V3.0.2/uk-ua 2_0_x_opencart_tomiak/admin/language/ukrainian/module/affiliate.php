<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']    = 'Партнерська програма';

$_['text_module']      = 'Модулі';
$_['text_success']     = 'Налаштування модуля оновлено!';
$_['text_edit']        = 'Редагування модуля';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає прав для управління цим модулем!';