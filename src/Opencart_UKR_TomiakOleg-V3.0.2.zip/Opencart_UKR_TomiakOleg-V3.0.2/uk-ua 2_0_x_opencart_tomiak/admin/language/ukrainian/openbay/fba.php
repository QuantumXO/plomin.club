<?php
// Heading
$_['heading_title']         	= 'Fulfillment від Amazon';
$_['text_openbay']				= 'OpenBay Pro';
$_['text_dashboard']			= 'Fulfillment від Amazon Dashboard';

// Text
$_['text_heading_settings'] 	= 'Налаштування';
$_['text_heading_account'] 		= 'Аккаунт/підписка';
$_['text_heading_fulfillments'] = 'Fulfillments';
$_['text_heading_register'] 	= 'Зареєструватись';
$_['text_heading_orders'] 		= 'Замовлення';