<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title']					     = 'Fulfillments';
$_['text_openbay']					     = 'OpenBay Pro';
$_['text_fba']						     = 'Fulfillment від Amazon';

// Buttons
//$_['button_pull_orders']        	     = 'Старт';

// Entry
$_['entry_start_date']             		 = 'Дата початку (формат YYYY-MM-DD)';

// Text
$_['text_no_results'] 					 = 'Не знайдено fulfillment\'s на Amazon';
$_['text_fulfillment_list'] 			 = 'Список Fulfillment на Амазон';

// Columns
$_['column_seller_fulfillment_order_id'] = 'ID Транзакції продавця';
$_['column_displayable_order_id'] 		 = 'Публічний Order ID';
$_['column_displayable_order_date'] 	 = 'Публічні дата/час';
$_['column_shipping_speed_category'] 	 = 'Швидкість доставки';
$_['column_fulfillment_order_status'] 	 = 'Статус замовлення';
$_['column_action'] 					 = 'Дія';

// Errors
//$_['error_validation']                 = 'Вам необхідно зареєструвати Ваш API token і включити модуль.';