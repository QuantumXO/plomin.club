<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Тема
$_['heading_title'] 		= 'Etsy';
$_['text_openbay'] 		= 'OpenBay експерт ';
$_['text_dashboard'] 		= 'Панель управління Etsy';

// Повідомлення
$_['text_success'] 		= 'Ви зберегли свої зміни з розширенням Etsy';
$_['text_heading_settings'] 	= 'Налаштування';
$_['text_heading_sync'] 	= 'Синхронізація';
$_['text_heading_register'] 	= 'Зареєструйтеся тут ';
$_['text_heading_products'] 	= 'Посилання на товар ';
$_['text_heading_listings'] 	= 'Etsy перелік ';

// Помилки
$_['error_generic_fail'] 	= 'Виникла невідома помилка! ';
$_['error_permission']   	= 'У Вас відсутні права для налаштування Etsy';