<?php
//Переклад: Том'як Олег з любов'ю до Української мови та легкості Opencart
// Text
$_['text_openbay_extension']           = 'OpenBay Pro (інтеграція)';
$_['text_openbay_dashboard']           = 'Панель управління';
$_['text_openbay_orders']              = 'Керування замовленнями';
$_['text_openbay_items']               = 'Управління товарами';
$_['text_openbay_ebay']                = 'eBay';
$_['text_openbay_amazon']              = 'Amazon (Європа)';
$_['text_openbay_amazonus']            = 'Amazon (США)';
$_['text_openbay_etsy']            	   = 'Etsy';
$_['text_openbay_settings']            = 'Налаштування';
$_['text_openbay_links']               = 'лінки на лоти';
$_['text_openbay_report_price']        = 'Звіт по цінах';
$_['text_openbay_order_import']        = 'Імпотрувати замовлення';
$_['text_openbay_fba']                 = 'Fulfillment від Amazon';
$_['text_openbay_fulfillmentlist']     = 'Fulfillments';
$_['text_openbay_orderlist']           = 'Замовлення';