<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
$_['heading_title'] = 'Яндекс.Каса (mPOS)';
?>