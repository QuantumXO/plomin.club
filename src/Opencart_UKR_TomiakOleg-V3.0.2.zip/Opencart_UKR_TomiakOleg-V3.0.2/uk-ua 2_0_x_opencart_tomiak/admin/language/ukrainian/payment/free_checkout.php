<?php
//Переклад: Том'як Олег tomjakoleg@ukr.net з любов'ю до Української мови та легкості Opencart
// Heading
$_['heading_title'] 	= 'Безкоштовне замовлення';
// Jtext
$_['text payment'] 	= 'Оплата';
$_['text_success'] 	= 'Налаштування модуля успішно оновлені!';
$_['text_edit'] 	= 'Редагування модуля';
// Entry
$_['entry_order_status'] = 'Статус замовлення:';
$_['entry_status'] 	= 'Статус:';
$_['entry_sort_order'] 	= 'Порядок сортування:';
// Error
$_['error_permission'] 	= 'Ви не маєте права на управління цим модулем!';