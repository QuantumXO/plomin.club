<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']    = 'Захист від зловмисників';

// Text
$_['text_success']     = 'Налаштування успешно обновлені!';
$_['text_list']        = 'Список модулів';

// Column
$_['column_name']      = 'Назва';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для зміни налаштуваннь!';

