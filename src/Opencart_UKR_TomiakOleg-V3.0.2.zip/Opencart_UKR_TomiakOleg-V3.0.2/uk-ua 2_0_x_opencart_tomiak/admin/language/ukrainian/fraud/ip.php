<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']      = 'Anti-Fraud IP модуль';

// Text
$_['text_fraud']         = 'Anti-Fraud';
$_['text_success']       = 'Успішно: Ви змінили налаштування Anti-Fraud IP!';
$_['text_edit']          = 'Редагувати Anti-Fraud IP';
$_['text_ip_add']        = 'Додати IP Адресу';
$_['text_ip_list']       = 'Fraud IP Address List';

// Column
$_['column_ip']          = 'IP';
$_['column_total']       = 'Всього аккаунтів';
$_['column_date_added']  = 'Дата додавання';
$_['column_action']      = 'Дія';

// Entry
$_['entry_ip']           = 'IP';
$_['entry_status']       = 'Статус';
$_['entry_order_status'] = 'Статус замовлення';

// Help
$_['help_order_status']  = 'Клієнти, які забанені по IP, на їх аккаунтах буде присвоєно цей статус замовлення і не буде дозволено автоматично отримувати інший статус.';

// Error
$_['error_permission']   = 'У Вас немає дозволів для керування модулем Anti-Fraud IP!';
