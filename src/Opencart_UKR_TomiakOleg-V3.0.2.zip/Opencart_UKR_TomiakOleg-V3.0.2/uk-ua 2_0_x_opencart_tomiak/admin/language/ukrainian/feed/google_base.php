<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']          = 'Google Base модуль';

// Text
$_['text_feed']              = 'Канали просування';
$_['text_success']           = 'Налаштування модуля оновлено!';
$_['text_edit']              = 'Редагувати Google Base';
$_['text_import']            = 'Для оновлення останньої версії Google категорії  <a href="https://support.google.com/merchants/answer/160081?hl=en" target="_blank" class="alert-link">clicking here</a> and choose taxonomy with numeric IDs in Plain Text (.txt) file. Upload via the green import button.';

// Column
$_['column_google_category'] = 'Google Категорії';
$_['column_category']        = 'Категорії';
$_['column_action']          = 'Дія';

// Entry
$_['entry_google_category']  = 'Google Category';
$_['entry_category']         = 'Category';
$_['entry_data_feed']        = 'URL канала:';
$_['entry_status']           = 'Статус:';

// Error
$_['error_permission']       = 'У Вас немає прав для управління Google Base!';
$_['error_upload']           = 'Файл не був завантажений!';
$_['error_filetype']         = 'Невірний тип файлу!';