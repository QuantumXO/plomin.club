<?php
//Переклад: Том’як Олег tomjakoleg@ukr.net з любов’ю до Української мови та легкості Opencart
// Heading
$_['heading_title']	  	= 'OpenBay Pro модуль';

// Text
$_['text_module']          	= 'Модулі';
$_['text_installed']          	= 'Модуль OpenBay Pro успішно встановлено. Для налаштувань перейдіть у меню: "Додатки> OpenBay Pro"!';
