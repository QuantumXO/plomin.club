## least.js 2 Changelog
> last change: 10/07/2014 - Version 2.2.0

## V - 2.2.0 (10/07/2014)
> added new flat close icon
> added new flat loading icon (thx Brent Jackson @jxnblk)
> added codekit config-files
> addes source map for .js and .css files
> added new option: add a link into your caption element
> added new option: title and caption are now editable as html-attribute

- added new flat close icon
- added codekit config 
- added source map
- added option to add a link into caption
- added new flat loading icon (thx Brent Jackson @jxnblk)
- title and subtible are now editable as html-attribute

## V - 2.1 (21/01/2014)
> added caption element for "image-preview"

## V - 2.0.1 (16/01/2014)
> initial release
